$(document).ready(function() {
  $(".editor").summernote({
    height: 520,
  });
});
